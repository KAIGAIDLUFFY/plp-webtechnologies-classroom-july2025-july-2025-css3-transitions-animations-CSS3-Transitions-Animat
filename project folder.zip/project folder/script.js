// Global scope variable
let baseBounty = 1000000;

// Function with parameter + return value
function calculateBounty(strength) {
  // Local scope variable
  let multiplier = 20000;
  return baseBounty + (strength * multiplier);
}

// DOM interaction using function
function showBounty() {
  let strengthInput = document.getElementById("strength").value;
  let result = document.getElementById("bountyResult");

  if (strengthInput === "" || strengthInput <= 0) {
    result.innerText = "⚠️ Please enter a valid strength!";
    return;
  }

  // Call function with parameter
  let bounty = calculateBounty(strengthInput);

  result.innerText = `💰 Your bounty is: ${bounty.toLocaleString()} Berries!`;
}

/* --------------------------
   Part 3: CSS + JS Combo
----------------------------- */
function togglePoster() {
  let poster = document.getElementById("poster");

  if (poster.classList.contains("hidden")) {
    poster.classList.remove("hidden");
    setTimeout(() => poster.classList.add("show"), 10); // Trigger CSS animation
  } else {
    poster.classList.remove("show");
    setTimeout(() => poster.classList.add("hidden"), 800); // Wait for fade-out
  }
}

/* --------------------------
   Devil Fruits Section
----------------------------- */
function revealFruit(fruit) {
  let result = document.getElementById("fruitResult");
  if (fruit === "gomu") {
    result.innerText = "🍎 Gomu Gomu no Mi: Grants rubber powers!";
  } else if (fruit === "mera") {
    result.innerText = "🔥 Mera Mera no Mi: Flame-human powers!";
  } else if (fruit === "ope") {
    result.innerText = "⚕️ Ope Ope no Mi: The ultimate surgical powers!";
  }
}

/* --------------------------
   Trivia Quiz Section
----------------------------- */
function checkAnswer(answer) {
  let result = document.getElementById("quizResult");
  if (answer === "Sanji") {
    result.innerText = "✅ Correct! Sanji is the cook of the crew.";
    result.style.color = "lightgreen";
  } else {
    result.innerText = "❌ Wrong! Try again.";
    result.style.color = "red";
  }
}
